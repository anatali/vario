java -cp soap.jar org.apache.soap.util.net.TcpTunnelGui $1 $2 $3
