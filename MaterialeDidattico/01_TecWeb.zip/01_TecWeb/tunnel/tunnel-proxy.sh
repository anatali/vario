java -cp soap.jar -Dhttp.proxySet=true -Dhttp.proxyHost=proxy.labx -Dhttp.proxyPort=8080 org.apache.soap.util.net.TcpTunnelGui $1 $2 $3
